#pip install pymongo
#Instalarse mongodb compass y abrir powershell escribir "mongod" para iniciar el servidor

from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017", serverSelectionTimeoutMS=3000)#27017 es el puerto por defecto de mongodb
    client.server_info()  # fuerza conexión
    
    db = client["Brainlab_DB"]

    collection = db["DataExperiments"]

    documents = collection.find()
    for document in documents:
        print(document)


except Exception as e:
    print(" Error de conexión:", e)
